/**
 * Internal dependencies
 */
import './checkout-newsletter-subscription-block';
