/**
 * Internal dependencies
 */
import Block from './block';

const FrontendBlock = ( props ) => {
	return <Block { ...props } />;
};

export default FrontendBlock;
