module.exports = {
	extends: [ 'plugin:@woocommerce/eslint-plugin/recommended' ],
};
